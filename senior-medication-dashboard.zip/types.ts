export interface MedicationRecord {
  patientid: string;
  name: string;
  medicationname: string;
  dosage: string;
  frequency: string;
  lastadministereddate: string;
  nextduedate: string;
  time: string;
  notes: string;
}
