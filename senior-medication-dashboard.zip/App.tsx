
import React, { useState, useEffect, useCallback } from 'react';
import { MEDICATION_CSV_DATA } from './constants';
import { MedicationRecord } from './types';

declare var Papa: any;

const Modal = ({ record, onClose, onSave, existingIds, displayNames, fieldOrder }: { 
    record: Partial<MedicationRecord>, 
    onClose: () => void, 
    onSave: (record: MedicationRecord) => void, 
    existingIds: string[],
    displayNames: { [key: string]: string },
    fieldOrder: (keyof MedicationRecord)[]
}) => {
    const [formData, setFormData] = useState<Partial<MedicationRecord>>(record);
    const isEditing = !!record.patientid;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isEditing && existingIds.includes(formData.patientid || '')) {
            alert('Patient ID must be unique.');
            return;
        }
        onSave(formData as MedicationRecord);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white p-8 rounded-lg shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
                <h2 className="text-2xl font-bold mb-6 text-gray-700">{isEditing ? 'Modify Patient Record' : 'Add New Patient'}</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    {fieldOrder.map((key) => (
                        <div key={key}>
                            <label className="block text-sm font-medium text-gray-600 capitalize">{displayNames[key]}</label>
                            <input
                                type="text"
                                name={key}
                                value={(formData as any)[key] || ''}
                                onChange={handleChange}
                                disabled={isEditing && key === 'patientid'}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                            />
                        </div>
                    ))}
                    <div className="flex justify-end gap-4 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">Save</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


export default function App() {
    const [medicationData, setMedicationData] = useState<MedicationRecord[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentRecord, setCurrentRecord] = useState<Partial<MedicationRecord> | null>(null);
    const [deleteId, setDeleteId] = useState('');

    const headers: (keyof MedicationRecord)[] = [
        "patientid", "name", "medicationname", "dosage", "frequency",
        "lastadministereddate", "nextduedate", "time", "notes"
    ];
    
    const headerDisplayNames: { [key in keyof MedicationRecord]: string } = {
        patientid: 'Patient ID',
        name: 'Name',
        medicationname: 'Medication Name',
        dosage: 'Dosage',
        frequency: 'Frequency',
        lastadministereddate: 'Last Administered Date',
        nextduedate: 'Next Due Date',
        time: 'Time',
        notes: 'Notes'
    };


    useEffect(() => {
        const parsedData = Papa.parse(MEDICATION_CSV_DATA, {
            header: true,
            skipEmptyLines: true,
            transformHeader: (header: string) => header.toLowerCase().replace(/ /g, '')
        });
        setMedicationData(parsedData.data as MedicationRecord[]);
    }, []);

    const handleOpenModal = (record: Partial<MedicationRecord> | null = null) => {
        const newRecord: Partial<MedicationRecord> = {};
        headers.forEach(header => (newRecord as any)[header] = record ? (record as any)[header] || '' : '');
        setCurrentRecord(newRecord);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setCurrentRecord(null);
    };

    const handleSaveRecord = (record: MedicationRecord) => {
        const isEditing = currentRecord && currentRecord.patientid && medicationData.some(r => r.patientid === currentRecord.patientid);

        if (isEditing) {
            setMedicationData(medicationData.map(r => r.patientid === record.patientid ? record : r));
        } else {
            setMedicationData([...medicationData, record]);
        }
        handleCloseModal();
    };

    const handleDeleteById = () => {
        const idToDelete = deleteId.trim();
        if (!idToDelete) {
            alert("Please enter a Patient ID to delete.");
            return;
        }
        if (window.confirm(`Are you sure you want to delete patient with ID ${idToDelete}?`)) {
            const newData = medicationData.filter(record => record.patientid.trim() !== idToDelete);
            if (newData.length === medicationData.length) {
                alert(`Patient with ID ${idToDelete} not found.`);
            } else {
                setMedicationData(newData);
                setDeleteId('');
                 alert(`Patient with ID ${idToDelete} has been successfully deleted.`);
            }
        }
    };
    
    const downloadCSV = useCallback(() => {
        const dataToExport = medicationData.map(record => {
            const newRecord: { [key: string]: string } = {};
            headers.forEach(header => {
                newRecord[headerDisplayNames[header]] = (record as any)[header];
            });
            return newRecord;
        });
        const csv = Papa.unparse(dataToExport);
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.setAttribute('download', 'medication_schedule.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }, [medicationData, headers, headerDisplayNames]);

    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <header className="text-center mb-8">
                <h1 className="text-4xl font-bold text-gray-700">Senior Medication Dashboard</h1>
            </header>

            <main>
                <div className="bg-white shadow-lg rounded-lg overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                {headers.map(header => (
                                    <th key={header} scope="col" className="px-6 py-3">{headerDisplayNames[header]}</th>
                                ))}
                                <th scope="col" className="px-6 py-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {medicationData.map((record) => (
                                <tr key={record.patientid} className="bg-white border-b hover:bg-gray-50">
                                    {headers.map(header => (
                                       <td key={`${record.patientid}-${header}`} className="px-6 py-4">{(record as any)[header]}</td>
                                    ))}
                                    <td className="px-6 py-4">
                                        <button onClick={() => handleOpenModal(record)} className="font-medium text-blue-600 hover:underline">Modify</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-lg shadow-lg col-span-1 md:col-span-1 flex flex-col items-start space-y-4">
                         <h3 className="text-lg font-semibold text-gray-700">Patient Management</h3>
                        <button onClick={() => handleOpenModal()} className="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                            Add New Patient
                        </button>
                         <div className="w-full">
                            <label htmlFor="deleteIdInput" className="block text-sm font-medium text-gray-600 mb-1">Delete Patient by ID</label>
                            <div className="flex gap-2">
                                <input 
                                    id="deleteIdInput"
                                    type="text" 
                                    value={deleteId}
                                    onChange={(e) => setDeleteId(e.target.value)}
                                    placeholder="Enter Patient ID"
                                    className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500"
                                />
                                <button onClick={handleDeleteById} className="bg-red-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-red-700 transition-colors">
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                     <div className="bg-white p-6 rounded-lg shadow-lg col-span-1 md:col-span-2 flex flex-col items-start space-y-4">
                        <h3 className="text-lg font-semibold text-gray-700">Export Data</h3>
                        <p className="text-sm text-gray-600">Download the current medication list as a CSV file. Any changes you've made will be included.</p>
                        <button onClick={downloadCSV} className="w-full md:w-auto bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                            Download Reminders CSV
                        </button>
                    </div>
                </div>
            </main>

            {isModalOpen && currentRecord && (
                <Modal 
                    record={currentRecord} 
                    onClose={handleCloseModal} 
                    onSave={handleSaveRecord}
                    existingIds={medicationData.map(r => r.patientid).filter(id => id !== currentRecord.patientid)}
                    displayNames={headerDisplayNames}
                    fieldOrder={headers}
                />
            )}
        </div>
    );
}
