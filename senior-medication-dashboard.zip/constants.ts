export const MEDICATION_CSV_DATA = `Patient ID,Name,Medication Name,Dosage,Frequency,Last Administered Date,Next Due Date,Time,Notes
01,John Smith,Aspirin,81 mg,Once Daily,8/22/2025,8/23/2025,09:00 AM,Take with food
02,Mary Johnson,Lisinopril,10 mg,Once Daily,8/22/2025,8/23/2025,09:00 AM,Blood pressure check required
03,Robert Brown,Metformin,500 mg,Twice Daily,8/22/2025,8/23/2025,10:00 PM,After meals
04,Alice Davis,Atorvastatin,20 mg,Once Daily,8/22/2025,8/23/2025,08:00 PM,Take at bedtime
05,Charles White,Warfarin,5 mg,Once Daily,8/21/2025,8/22/2025,09:00 AM,Regular INR tests
06,Susan Green,Ibuprofen,200 mg,As Needed,8/20/2025,8/23/2025,12:00 PM,For pain relief`;
